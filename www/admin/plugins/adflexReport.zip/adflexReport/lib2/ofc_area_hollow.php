<?php

class area_hollow extends area_base
{
	function area_hollow()
	{
		$this->type      = "area_hollow";
		parent::area_base();
	}
}
